# Handoff: HSHT Enrollment — Dashboard Redesign

## Overview
This is a modernized redesign of the HSHT Enrollment admin dashboard — the "Home" screen of an
application that Administration uses to track student enrollment in school-sponsored activities
(students, schools, school districts, activities, and participation).

The redesign keeps the **familiar layout** of the legacy app (left navigation rail, KPI cards row,
a large enrollment chart with three mini-metrics, a "Top Enrollment" side panel, and an activity
schedule table) but rebuilds it with cleaner typography, better spacing, clearer charts, and a
live status/trend layer.

Two themes were approved and should both be implemented, selectable by the user:
- **Aurora** — light UI, indigo primary on a cool-neutral background.
- **Midnight** — dark UI, slate surfaces with a cyan data accent.

A third theme, **Heritage** (light content + deep-green sidebar, teal/amber accents), is documented
below as an optional additional choice — the tokens are included so it can be dropped into the
theme switch later.

## About the Design Files
The files in this bundle (`*.dc.html`) are **design references authored in HTML** — prototypes that
show the intended look, layout, and behavior. **They are not production code to copy directly.** The
`.dc.html` format and `support.js` are a prototyping runtime only; ignore them for implementation.

The task is to **recreate these designs in the target application's environment** using its
established patterns and libraries. If the app already has a stack (e.g. React + a component library,
Vue, Blazor, server-rendered templates), build the dashboard there with existing conventions. If no
frontend environment exists yet, choose an appropriate modern stack (React + a charting lib such as
Recharts/visx, or equivalent) and implement it there. Match the visuals below pixel-for-pixel;
source the structure/behavior from this README.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, radii, and interactions are final. Recreate
the UI precisely using the target codebase's libraries. Where this doc gives exact hex/px values,
use them.

---

## Layout (App Shell)

Top-level is a horizontal flex row filling the app width; two children:

```
┌────────────┬──────────────────────────────────────────────┐
│  SIDEBAR   │  TOPBAR (h: 64px)                              │
│  (236px,   ├──────────────────────────────────────────────┤
│  collapses │  CONTENT (padding: 22px 24px 26px; gap: 20px) │
│  to 74px)  │   • KPI grid (4 cols)                         │
│            │   • Chart row: [Enrollment chart | Top Enrl]  │
│            │   • Activity Schedule card                    │
└────────────┴──────────────────────────────────────────────┘
```

- **Root container:** `display:flex`; `border-radius:16px`; `overflow:hidden`; background `--app-bg`;
  base font `'Manrope', system-ui, sans-serif`; text color `--text`.
  (The 16px radius + drop shadow are just for the prototype canvas; in-app the shell is full-bleed.)
- **Sidebar:** fixed width `236px` (expanded) / `74px` (collapsed); `flex:none`; background
  `--sidebar-bg`; right border `1px solid --sidebar-border`; vertical flex column; padding `18px 14px 20px`.
- **Main:** `flex:1; min-width:0`; vertical flex column.
- **Topbar:** height `64px`; `flex:none`; background `--surface`; bottom border `1px solid --border`;
  horizontal flex, `align-items:center`, `gap:16px`, padding `0 24px`.
- **Content:** padding `22px 24px 26px`; vertical flex column; `gap:20px`.

Reference width used in the mockups: **1180px**. It is fluid — the content column flexes; only the
sidebar, the Top Enrollment panel (322px), and the weekly-activity panel (288px) are fixed-width.

---

## Screens / Components

### 1. Sidebar (navigation rail)

**Brand block** (top): a 38×38 rounded-square logo mark (`--primary` bg, white "HE", radius 10px,
weight 800) + two-line wordmark — "HSHT" (15px / 800 / `--sidebar-brand`) over "ENROLLMENT"
(10px / 600 / letter-spacing .16em / `--sidebar-muted`). Padding `6px 8px 22px`.

**Section label:** "GENERAL" — 10px / 700 / letter-spacing .14em / `--sidebar-muted`, padding `0 10px 8px`.

**Nav items** (in order): Home *(active)*, Activity ▾, Invoices ▾, Students, Schools,
School Districts, Reports ▾, Enrollment Forms, Exports ▾, Utility ▾.
- Each item: `display:flex; align-items:center; gap:12px`; padding `10px 12px`; radius 10px;
  font 13.5px; icon 18px (1.9 stroke, `stroke-linecap/linejoin:round`), `stroke=currentColor`.
- Items marked ▾ (expandable menus) have a 14px chevron pushed right via `margin-left:auto`.
- **Default item:** weight 600, color `--sidebar-text`. **Hover:** background `--sidebar-hover`.
- **Active item (Home):** weight 700, color `--sidebar-active-text`, background `--sidebar-active-bg`.
- Row spacing: `margin-bottom:3px`.

**Footer** (pushed to bottom with `margin-top:auto`; top border `1px solid --sidebar-border`;
padding `14px 12px 4px`): 32×32 avatar chip ("HC", radius 9px, bg `--c2s`, color `--c2`, weight 800)
+ "hcsupport" (12.5px / 700 / `--sidebar-brand`) over "Administrator" (11px / `--sidebar-muted`).

**Collapsed state (74px rail):** hide the wordmark, "GENERAL" label, all nav text labels, all
chevrons, and the footer text — keep only centered icons (and centered logo/avatar). Center each
row's content (`justify-content:center`). The collapse is toggled by the topbar menu button. In
production, show a tooltip with the label on hover of each collapsed icon (not built in the mock).
Implemented in the prototype via CSS custom properties: `--nav-w`, `--lbl` (label `display`),
`--brand` (brand/footer text `display`), `--chev` (chevron `display`), `--nav-just`, `--brand-just`.

### 2. Topbar

Left → right:
- **Menu button** (toggles sidebar collapse): 36×36, radius 9px, `1px solid --border` border,
  transparent bg, `--muted` icon (hamburger, 18px, 2px stroke).
- **Title block:** "Dashboard" (16px / 800 / `--heading` / letter-spacing -.01em) over
  "Enrollment overview · July 2026" (11.5px / `--muted`).
- **Right cluster** (`margin-left:auto; display:flex; align-items:center; gap:12px`):
  - **Theme switch** *(only when themeable)* — see Interactions. A segmented pill: 38px tall, padding
    4px, radius 11px, bg `--surface-2`, `1px solid --border`. Two segments "Light" / "Dark" each with a
    15px icon (sun / moon). **Active segment:** weight 700, bg `--surface`, color `--text`,
    `box-shadow:0 1px 3px rgba(0,0,0,.16)`, radius 8px, padding `6px 11px`. **Inactive:** weight 600,
    transparent bg, color `--muted`.
  - **Search** (display-only in mock): 38px tall, width 210px, radius 10px, bg `--surface-2`,
    `1px solid --border`, `--muted`; 16px search icon + "Search students, schools…" (12.5px).
  - **Notifications:** 38×38 button, radius 10px, bg `--surface-2`, `1px solid --border`; bell icon;
    badge top-right: min-width 17px, height 17px, radius 9px, bg `--primary`, white, 10px/800,
    `2px solid --surface` ring; value "2".
  - **User chip:** 38px tall, radius 10px, `1px solid --border`, bg `--surface-2`, padding `0 8px 0 6px`;
    28×28 avatar ("HC", radius 8px, `--primary` bg, white, 11px/800) + "hcsupport" (12.5px/700/`--text`)
    + 14px chevron (`--muted`).

### 3. KPI cards (row of 4)

`display:grid; grid-template-columns:repeat(4,1fr); gap:16px`. Each card: bg `--surface`,
`1px solid --border`, radius 14px, padding `18px 18px 16px`.

Card body: a flex row (`justify-content:space-between; align-items:flex-start`):
- Left: **value** (30px / 800 / letter-spacing -.02em / `--heading` / line-height 1),
  then label (13.5px / 700 / `--text`, margin-top 9px), then sublabel (11.5px / `--muted`).
- Right: 44×44 icon chip, radius 12px, bg `--cNs`, color `--cN`, 22px icon centered.

Trend row (margin-top 14px, flex, gap 7px): a pill (font 11.5px / 800; padding `3px 8px`; radius 20px)
with a tiny 9px triangle glyph + percentage, then muted caption.

| # | Value | Label | Sublabel | Icon | Chip color | Trend |
|---|-------|-------|----------|------|-----------|-------|
| 1 | 1,847 | Students | Total enrolled | person | c1 | ▲ 12.4% (positive) · "vs last month" |
| 2 | 342 | Activities | Total year to date | pulse | c2 | ▲ 6.1% (positive) · "vs last month" |
| 3 | 293 | Schools | Total active | building | c3 | ▲ 2.0% (positive) · "vs last month" |
| 4 | 156 | Districts | Total active | org-tree | c4 | — 0.0% (muted, bg `--surface-2`) · "no change" |

Positive pill: color `--positive`, bg `--positive-soft`. Neutral pill: color `--muted`, bg `--surface-2`.

### 4. Enrollment Summary (chart card)

`flex:1; min-width:0`; bg `--surface`; `1px solid --border`; radius 14px; padding `20px 22px 18px`;
flex column.

- **Header:** "Enrollment Summary" (15px / 800 / `--heading`) + "Weekly progress" (11.5px / `--muted`),
  and a right-aligned legend chip: "Email Sent" — 11.5px/700/`--muted`, bg `--surface-2`,
  `1px solid --border`, padding `5px 10px`, radius 8px, with a 9px `--accent` square swatch.
- **Line/area chart** — SVG `viewBox="0 0 920 240"`, width 100%.
  - 5 horizontal gridlines at y = 30, 75, 120, 165, 210 (`--grid`; baseline at 210 uses 1.5px).
  - Y-axis labels (right-aligned at x=20, 11px, `--muted`): 120, 90, 60, 30, 0.
  - **Area** fill `--accent` at `fill-opacity:0.13`. **Line** stroke `--accent`, width 2.5,
    round caps/joins, no fill.
  - **Dots** at each data point: r 3.6, fill `--surface`, stroke `--accent` width 2.
  - Data (14 pts, value scale 0–120): `35, 44, 48, 45, 51, 56, 52, 57, 61, 59, 56, 67, 73, 85`.
    Point geometry (x,y in viewBox): (30,157.5) (96.2,144) (162.3,138) (228.5,142.5) (294.6,133.5)
    (360.8,126) (426.9,132) (493.1,124.5) (559.2,118.5) (625.4,121.5) (691.5,126) (757.7,109.5)
    (823.8,100.5) (890,82.5). X maps 30→890 across the 14 points; Y = 210 − (value/120)·180.
  - X-axis labels below (flex row, space-between, 11px `--muted`, left padding 30px):
    13/07, 16/07, 19/07, 22/07, 25/07, 28/07, 31/07.
- **Mini-metrics** (below chart, `border-top:1px solid --border`, margin/padding-top 16px):
  `grid-template-columns:repeat(3,1fr); gap:16px`. Each = a label (11.5px/600/`--muted`) over a row
  with a big value (20px/800/`--heading`) + a small positive delta (11px/700/`--positive`), and a
  sparkline (width 96px, height 32px) on the right.
  - **Total Students** — 1,847 · +8.2% · bar sparkline, color `--c1` (opacity .8).
    Bars (% heights): `46,62,40,68,52,78,58,50,72,64,44,80,56,70`.
  - **Total Invoicing** — $48,250 · +5.1% · line sparkline (SVG `viewBox 0 0 160 44`), stroke `--c2`
    width 2, area fill `--c2` `fill-opacity 0.14`.
  - **Total Enrollment** — 2,190 · +11.0% · bar sparkline, color `--c3` (opacity .8).
    Bars (% heights): `56,48,66,54,74,60,50,68,62,78,52,70,58,82`.

### 5. Top Enrollment (side panel)

`width:322px; flex:none`; bg `--surface`; `1px solid --border`; radius 14px; padding `20px 20px 12px`.
Header: "Top Enrollment" (15px/800/`--heading`) + right-aligned "View all" (11.5px/700/`--accent`).

Five rows. Each: `display:flex; align-items:center; gap:12px`; padding `10px 8px`; radius 10px;
**hover** bg `--surface-2`. Left: 36×36 icon chip (radius 10px, building icon 19px) cycling colors
c1→c2→c3→c4→c1. Middle (`flex:1; min-width:0`): school name (13px/700/`--text`) over county
(11.5px/`--muted`). Right (text-align right): count (15px/800/`--heading`) over "students" (10.5px/`--muted`).

| School | County | Students | Chip |
|--------|--------|----------|------|
| Pierce County High School | Pierce County | 24 | c1 |
| Fannin County High School | Fannin County | 20 | c2 |
| Richmond Hill High School | Bryan County | 16 | c3 |
| Bacon County High School | Bacon County | 11 | c4 |
| Valdosta High School | Lowndes County | 10 | c1 |

### 6. Activity Schedule (table + weekly chart)

Full-width card: bg `--surface`; `1px solid --border`; radius 14px; `overflow:hidden`.
- **Header** (padding `18px 22px 14px`, flex space-between): "Activity Schedule" (15px/800/`--heading`)
  + "Weekly summary" (11.5px/`--muted`); right-aligned "Export" (11.5px/700/`--accent`).
- **Body:** flex row, `align-items:stretch`.
  - **Table** (`flex:1; min-width:0`; padding `0 8px 8px`). Header row + data rows share the grid
    `grid-template-columns: 36px 92px 1.1fr 1.2fr 1.4fr 88px`.
    - Header cells: 10.5px / 800 / letter-spacing .05em / uppercase / `--muted`; padding `8px 14px`.
      Columns: `#`, Date, Activity, School, Description, Status *(right-aligned)*.
    - Data rows: `align-items:center`; padding `11px 14px`; font 12.5px; `border-top:1px solid --border`.
      `#` (700/`--muted`), Date (`--muted`), Activity (700/`--text`), School (`--text`),
      Description (`--muted`), Status = a pill (10.5px/800; padding `3px 9px`; radius 20px).
    - Status pills: **Active** → `--positive` on `--positive-soft`; **Pending** → `--c3` on `--c3s`;
      **Closed** → `--muted` on `--surface-2`.

    | # | Date | Activity | School | Description | Status |
    |---|------|----------|--------|-------------|--------|
    | 1 | Jul 08 | Robotics Club | Pierce County HS | Regional qualifier prep | Active |
    | 2 | Jul 07 | Debate Team | Valdosta HS | Weekly practice session | Active |
    | 3 | Jul 05 | Marching Band | Richmond Hill HS | Summer camp enrollment | Pending |
    | 4 | Jul 03 | Track & Field | Fannin County HS | Meet registration | Active |
    | 5 | Jul 01 | Science Olympiad | Bacon County HS | Team roster update | Closed |

  - **Weekly activity panel** (`width:288px; flex:none`; `border-left:1px solid --border`;
    padding `16px 20px 18px`; flex column). Title "Weekly activity" (12.5px/700/`--text`) + subtitle
    "Participation events logged" (11px/`--muted`). Bar chart: flex row of 28 bars, `align-items:flex-end`,
    `gap:3px`, height 96px, each bar `flex:1`, radius `3px 3px 0 0`, bg `--accent`, opacity .85.
    Bar % heights: `52,68,45,74,58,86,60,50,78,66,44,82,56,72,54,88,48,64,79,52,92,60,70,55,80,63,49,74`.
    Axis labels below (space-between, 10.5px/`--muted`): Mon, Wed, Fri, Sun.

---

## Interactions & Behavior

- **Theme switch (Light / Dark).** Segmented control in the topbar. Clicking a segment swaps the
  entire dashboard's color tokens between the **Aurora** (light) and **Midnight** (dark) sets. The
  active segment is highlighted (see topbar spec).
  - **Persistence:** the choice is saved to `localStorage` under key **`hsht-dashboard-theme`** with
    value `"light"` or `"dark"`. On load, read this key and apply it; default to `"light"` if unset.
  - Recommended production home for the control: the user menu or a Settings → Appearance panel.
    Optional enhancement: a "System" option that follows `prefers-color-scheme`.
- **Sidebar collapse.** The topbar menu (hamburger) button toggles the rail between 236px (labels)
  and 74px (icons only). Persist this too if desired (not implemented in the mock). Add hover
  tooltips on collapsed icons.
- **Hover states.** Nav items → bg `--sidebar-hover`. Top Enrollment rows → bg `--surface-2`.
  All buttons/pills use `cursor:pointer`.
- **Transitions.** Theme-segment styles transition `all .15s`. A subtle theme cross-fade and a width
  transition on the sidebar collapse are nice-to-have.

## State Management
- `theme: 'light' | 'dark'` — controls active token set; initialized from `localStorage`
  (`hsht-dashboard-theme`), written on change.
- `sidebarCollapsed: boolean` — controls rail width / label visibility.
- All dashboard data (KPI figures, chart series, top-enrollment list, activity rows) is currently
  **static sample data** — wire these to the real enrollment/activity/invoicing APIs. The exact
  sample values above are placeholders for layout, not real figures.

---

## Design Tokens

Typography: **Manrope** (Google Fonts), weights 400/500/600/700/800. Numerals use the same family
(tabular feel). Font stack: `'Manrope', system-ui, sans-serif`.

Radii: root shell 16 · cards 14 · icon chips 10–12 · buttons/pills(controls) 8–11 · status/trend pills 20 (full).
Spacing: content padding `22 24 26`; card gap 20; KPI grid gap 16; card inner padding ~18–22.
Fixed widths: sidebar 236 / 74 · Top Enrollment 322 · Weekly panel 288 · topbar height 64.
Shadow (cards, optional/subtle): `0 1px 2px rgba(16,24,40,.04)`.

### Theme: Aurora (light)
```
--app-bg:#eef1f6      --surface:#ffffff     --surface-2:#f5f7fb   --border:#e8ebf2
--text:#1f2733        --muted:#6b7688       --heading:#0f172a
--sidebar-bg:#ffffff  --sidebar-border:#eef0f5  --sidebar-text:#5b6478  --sidebar-muted:#9aa2b4
--sidebar-brand:#0f172a  --sidebar-active-bg:#eef1ff  --sidebar-active-text:#4f46e5  --sidebar-hover:#f5f7fb
--primary:#4f46e5     --accent:#4f46e5      --grid:#eef1f6
--positive:#0e9f6e    --positive-soft:#e6f6ef
--c1:#4f46e5 / --c1s:#eef1ff   --c2:#0ea5e9 / --c2s:#e5f6fe
--c3:#f59e0b / --c3s:#fef3e0   --c4:#ec4899 / --c4s:#fdeaf3
```

### Theme: Midnight (dark)
```
--app-bg:#0a1020      --surface:#121c30     --surface-2:#0e1626   --border:#202b44
--text:#e5ecf7        --muted:#8b97b0       --heading:#f2f6fd
--sidebar-bg:#0a1020  --sidebar-border:#1a2338  --sidebar-text:#8b97b0  --sidebar-muted:#5a6683
--sidebar-brand:#eef2fb  --sidebar-active-bg:rgba(56,224,222,.13)  --sidebar-active-text:#38e0de  --sidebar-hover:rgba(255,255,255,.04)
--primary:#38e0de     --accent:#38e0de      --grid:#1c2740
--positive:#34d399    --positive-soft:rgba(52,211,153,.15)
--c1:#38e0de / --c1s:rgba(56,224,222,.15)   --c2:#7c8cff / --c2s:rgba(124,140,255,.17)
--c3:#fbbf24 / --c3s:rgba(251,191,36,.15)   --c4:#f472b6 / --c4s:rgba(244,114,182,.15)
```

### Theme: Heritage (light + dark-green sidebar) — optional
```
--app-bg:#f6f4ee      --surface:#ffffff     --surface-2:#faf8f2   --border:#ece7db
--text:#1c2b28        --muted:#6d7c78       --heading:#122d29
--sidebar-bg:#10312c  --sidebar-border:rgba(255,255,255,.09)  --sidebar-text:rgba(234,241,239,.74)  --sidebar-muted:rgba(234,241,239,.44)
--sidebar-brand:#ffffff  --sidebar-active-bg:rgba(255,255,255,.1)  --sidebar-active-text:#f4c04e  --sidebar-hover:rgba(255,255,255,.05)
--primary:#0f766e     --accent:#0f766e      --grid:#ece9df
--positive:#0f766e    --positive-soft:#e2f1ef
--c1:#0f766e / --c1s:#e2f1ef   --c2:#b45309 / --c2s:#f7ecda
--c3:#c2851b / --c3s:#f8f0dc   --c4:#8a5a2b / --c4s:#f4ebe0
```

> Implementation tip: define one set of semantic CSS variables (as above) and switch the values by a
> `data-theme="light|dark"` attribute on a root element (or a CSS-in-JS theme object). Every component
> reads only the semantic tokens, so adding "Heritage" later is just another value set + a switch option.

## Assets
- **Icons:** all icons are simple inline stroke SVGs (1.9–2px stroke, round caps/joins) — home, activity
  (pulse), invoice (doc), student (person), school (building), districts (org-tree), reports (bars),
  clipboard, upload, gear, hamburger, search, bell, chevron, sun, moon, plus a small filled triangle for
  trend arrows. Replace with the target codebase's existing icon set (e.g. Lucide/Feather/Heroicons) —
  the shapes map 1:1 to common line-icon libraries.
- **Logo:** placeholder "HE" monogram tile. Swap for the real HSHT Enrollment logo.
- **Fonts:** Manrope via Google Fonts (`https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800`).
- No raster images are used.

## Files
- `Enrollment Dashboard - Directions.dc.html` — the full design canvas: three theme directions (Aurora /
  Midnight / Heritage), the collapsed-rail variants, and the live theme-toggle demo. Open in a browser to
  see everything.
- `Dashboard.dc.html` — the reusable dashboard mockup (themed via CSS variables; supports `themeable`,
  `collapsed`, and per-theme token props). This is the single source of the layout above.
- `support.js` — prototyping runtime for the `.dc.html` files. **Not for production** — required only to
  render the reference HTML locally.
